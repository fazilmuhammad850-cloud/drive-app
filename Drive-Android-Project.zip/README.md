# Drive Android App

A simple offline-first Android WebView wrapper for the Drive trip and fuel log.

## Build
The GitHub Actions workflow in `.github/workflows/build.yml` builds a debug APK and uploads it as an artifact.
